# text-to-speech
A python package that says something of your choice

## Installation
To install the package run this command:

```bash
  pip install text-to-speech
```

## Usage

### Speak

```python
speak("text")
```

Demo:

```python
import text_to_speech as speech

speech.speak("text")
```